//
//  Item.swift
//  OrganaizerX
//
//  Created by Alex on 2/29/16.
//  Copyright © 2016 Alex. All rights reserved.
//

import Foundation
import CoreData


class Item: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
